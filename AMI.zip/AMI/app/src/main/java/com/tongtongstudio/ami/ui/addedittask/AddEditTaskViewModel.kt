package com.tongtongstudio.ami.ui.addedittask

import androidx.lifecycle.SavedStateHandle
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.tongtongstudio.ami.R
import com.tongtongstudio.ami.data.Nature
import com.tongtongstudio.ami.data.PreferencesManager
import com.tongtongstudio.ami.data.Repository
import com.tongtongstudio.ami.data.datatables.*
import com.tongtongstudio.ami.ui.*
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.channels.Channel
import kotlinx.coroutines.flow.receiveAsFlow
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class AddEditTaskViewModel @Inject constructor(
    private val repository: Repository,
    preferencesManager: PreferencesManager,
    private val state: SavedStateHandle
) : ViewModel() {


    private val addEditChannelEvent = Channel<AddEditTaskEvent>()
    val addEditTaskEvent = addEditChannelEvent.receiveAsFlow()

    // TODO: 21/06/2022 create a better variable for project id
    var projectId: Long? = null

    val thingToDo = state.get<ThingToDo>("thingToDo")

    val createdDateFormatted = thingToDo?.getCreatedDateFormatted()

    var name =
        state.get<String>("thingToDoName") ?: thingToDo?.name ?: ""
        set(value) {
            field = value
            state.set("thingToDoName", value)
        }


    var priority =
        state.get<String>("ThingToDoPriority") ?: thingToDo?.priority.toString()
        set(value) {
            field = value
            state.set("thingToDoPriority", value)
        }

    // TODO: 31/10/2022 estimated time of the work with an horloge
    var estimatedTime: Long? =
        state.get<Long>("estimatedTime") ?: thingToDo?.getEstimatedTime() ?: 0
        set(value) {
            field = value
            state.set("estimatedTime", value)
        }

    /*fun onDateSetByTheUser(instance: Calendar, year: Int, month: Int, dayOfMonth: Int) {
        val newDeadLine = instance.run {
            set(Calendar.YEAR, year)
            set(Calendar.MONTH, month)
            set(Calendar.DAY_OF_MONTH, dayOfMonth)
            time
        }
        deadline = DateFormat.getDateInstance(DateFormat.MEDIUM).format(newDeadLine)
    }*/

    private var thingToDoIsSubTask =
        state.get<Boolean>("thingToDoIsSubTask") ?: when (thingToDo) {
            is Task -> thingToDo.projectId != null
            else -> false
        }
        set(value) {
            field = value
            state.set("thingToDoIsSubTask", value)
        }

    var reminder: Long? =
        state.get<Long>("reminder") ?: thingToDo?.getReminder()
        set(value) {
            field = value
            state.set("reminder", value)
        }

    var deadline =
        state.get<Long?>("thingToDoDeadline") ?: thingToDo?.deadline
        set(value) {
            field = value
            state.set("thingToDoDeadline", value)
        }

    // TODO: 31/10/2022 make all type thing to do repeatable
    var protocolRepeatable =
        state.get<String>("protocolRepeatable") ?: when (thingToDo) {
            is Task -> thingToDo.protocolRepeatable
            else -> null
        }
        set(value) {
            field = value
            state.set("protocolRepeatable", value)
        }

    var isRecurring = state.get<Boolean>("isRecurring") ?: when (thingToDo) {
        is Task -> thingToDo.isRecurring
        else -> false
    }
        set(value) {
            field = value
            state.set("isRecurring", value)
        }

    var eventBeginningDate =
        state.get<String>("eventBeginningDate") ?: when (thingToDo) {
            is Event -> thingToDo.beginningDate
            else -> null
        }
        set(value) {
            field = value
            state.set("eventBeginningDate", value)
        }

    var eventIsSpread =
        state.get<Boolean>("eventIsSpread") ?: when (thingToDo) {
            is Event -> thingToDo.isSpread
            else -> false
        }
        set(value) {
            field = value
            state["eventIsSpread"] = value
        }

    var eventEndingDate =
        state.get<String>("eventEndingDate") ?: when (thingToDo) {
            is Event -> thingToDo.endingDate
            else -> null
        }
        set(value) {
            field = value
            state["eventEndingDate"] = value
        }

    var ttdNature =
        state.get<String>("thingToDoNature") ?: when (thingToDo) {
            is Task -> Nature.TASK.name
            is ProjectWithSubTasks -> Nature.PROJECT.name
            is Event -> Nature.EVENT.name
            else -> Nature.TASK.name
        }
        set(value) {
            field = value
            state.set("thingToDoNature", value)
        }

    fun radioBtnCheckedChange(checkedId: Int) {
        ttdNature = when (checkedId) {
            R.id.rb_project -> Nature.PROJECT.name
            R.id.rb_task -> Nature.TASK.name
            R.id.rb_event -> Nature.EVENT.name
            else -> Nature.TASK.name
        }
    }


    fun onSaveClick() {
        thingToDo?.let {
            val isSameNatureTTD = when (it) {
                is Task -> Nature.TASK.name == ttdNature
                is ProjectWithSubTasks -> Nature.PROJECT.name == ttdNature
                is Event -> Nature.EVENT.name == ttdNature
                else -> false
            }
            updateThingToDo(it, isSameNatureTTD)
        } ?: saveThingToDo()
    }


    private fun saveThingToDo() = viewModelScope.launch {
        when (ttdNature) {
            Nature.TASK.name -> {
                // TODO: 07/11/2022 take off possibility to change type of ttd if it's a sub task
                val newTask =
                    Task(
                        name,
                        priority.toInt(),
                        deadline,
                        isRecurring,
                        protocolRepeatable,
                        estimatedTime,
                        taskReminder = reminder
                    )
                if (projectId != null) {
                    repository.insertTask(newTask.copy(projectId = projectId))
                    val projectLinked = repository.getProjectData(projectId!!).project
                    repository.updateProject(projectLinked.copy(nb_sub_task = projectLinked.nb_sub_task + 1))
                } else {
                    repository.insertTask(newTask)
                }

                addEditChannelEvent.send(
                    AddEditTaskEvent.NavigateBackWithResult(
                        ADD_TASK_RESULT_OK
                    )
                )
            }
            Nature.PROJECT.name -> {
                repository.insertProject(
                    Project(
                        name,
                        priority.toInt(),
                        deadline,
                        estimatedTime,
                        pjtReminder = reminder
                    )
                )
                addEditChannelEvent.send(
                    AddEditTaskEvent.NavigateBackWithResult(
                        ADD_PROJECT_RESULT_OK
                    )
                )
            }
            Nature.EVENT.name -> {
                repository.insertEvent(
                    Event(
                        name,
                        priority.toInt(),
                        deadline,
                        estimatedTime,
                        beginningDate = eventBeginningDate,
                        endingDate = eventEndingDate,
                        isSpread = eventIsSpread,
                        eventReminder = reminder
                    )
                )
                addEditChannelEvent.send(
                    AddEditTaskEvent.NavigateBackWithResult(
                        ADD_EVENT_RESULT_OK
                    )
                )
            }
        }
    }

    private fun updateThingToDo(thingToDo: ThingToDo, isSameNature: Boolean) =
        viewModelScope.launch {
            // TODO: 21/10/2022 update method to change a type of thing to do and for update an old item
            when (thingToDo) {
                is Task -> {
                    if (isSameNature) {
                        repository.updateTask(
                            thingToDo.copy(
                                name,
                                priority.toInt(),
                                deadline,
                                isRecurring,
                                protocolRepeatable,
                                estimatedTime,
                                taskReminder = reminder
                            )
                        )
                    } else {
                        repository.deleteTask(thingToDo)
                        saveThingToDo()
                    }
                    // TODO: 08/11/2022 change message for another type saved
                    addEditChannelEvent.send(
                        AddEditTaskEvent.NavigateBackWithResult(
                            EDIT_TASK_RESULT_OK
                        )
                    )
                }
                is ProjectWithSubTasks -> {
                    if (isSameNature) {
                        repository.updateProject(
                            thingToDo.project.copy(
                                pjtName = name,
                                pjtPriority = priority.toInt(),
                                pjtDeadline = deadline,
                                pjtEstimatedTime = estimatedTime,
                                pjtReminder = reminder
                            )
                        )
                    } else {
                        repository.deleteProject(thingToDo.project)
                        saveThingToDo()
                    }
                    addEditChannelEvent.send(
                        AddEditTaskEvent.NavigateBackWithResult(
                            EDIT_PROJECT_RESULT_OK
                        )
                    )
                }
                is Event -> {
                    if (isSameNature) {
                        repository.updateEvent(
                            thingToDo.copy(
                                name,
                                priority.toInt(),
                                deadline,
                                estimatedTime,
                                beginningDate = eventBeginningDate,
                                endingDate = eventEndingDate,
                                isSpread = eventIsSpread,
                                eventReminder = reminder
                            )
                        )
                    } else {
                        repository.deleteEvent(thingToDo)
                        saveThingToDo()
                    }
                    addEditChannelEvent.send(
                        AddEditTaskEvent.NavigateBackWithResult(
                            EDIT_EVENT_RESULT_OK
                        )
                    )
                }
            }
        }

    fun showInvalidInputMessage(invalidUserMsg: String) = viewModelScope.launch {
        addEditChannelEvent.send(AddEditTaskEvent.ShowInvalidInputMessage(invalidUserMsg))
    }

    fun onRecurringChoiceResult(codeRef: String?): List<String>? {
        return if (codeRef != null) {
            isRecurring = true
            protocolRepeatable = codeRef
            val codeList = codeRef.split("/")
            codeList
        } else {
            isRecurring = false
            protocolRepeatable = null
            null
        }
    }

    sealed class AddEditTaskEvent {
        data class ShowInvalidInputMessage(val msg: String) : AddEditTaskEvent()
        data class NavigateBackWithResult(val result: Int) : AddEditTaskEvent()
        //object NavigatePickerDateScreen : AddEditTaskEvent()
    }
}