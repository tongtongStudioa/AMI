package com.tongtongstudio.ami.data.datatables

import android.os.Parcelable
import androidx.room.ColumnInfo
import androidx.room.Entity
import androidx.room.PrimaryKey
import kotlinx.android.parcel.Parcelize
import java.text.DateFormat

@Parcelize
@Entity(tableName = "task_table")
data class Task(
    val taskName: String,
    val taskPriority: Int,
    val taskDeadline: Long? = null,
    @ColumnInfo(name = "is_recurring") val isRecurring: Boolean = false,
    @ColumnInfo(name = "protocol_repeatable") val protocolRepeatable: String? = null,
    @ColumnInfo(name = "estimated_time") val taskEstimatedTime: Long? = null,
    @ColumnInfo(name = "work_time") val taskWorkTime: Long? = null,
    val isTaskCompleted: Boolean = false,
    val taskCompletedDate: String? = null,
    val taskReminder: Long? = null, //reminder date in millis
    //unique properties
    val nbCycle: Int = 0,
    val nbCompleted: Int = 0,
    /****///val streak: Int? = null, /count streak if it's a recurring task
    //val maxStreak: Int? = null, / max streak ?
    @ColumnInfo(name = "project_id") val projectId: Long? = null,
    // unique thing to do's id
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    @ColumnInfo(name = "created_date") val taskCreatedDate: Long = System.currentTimeMillis(),
) : ThingToDo(taskName, taskPriority, taskDeadline, taskCompletedDate), Parcelable {
    override fun getCreatedDateFormatted(): String {
        return DateFormat.getDateInstance().format(taskCreatedDate)
    }

    override fun getEstimatedTime(): Long? {
        return taskEstimatedTime
    }

    override fun getWorkTime(): Long? {
        return taskWorkTime
    }

    override fun isCompleted(): Boolean {
        return isTaskCompleted
    }

    override fun getReminder(): Long? {
        return taskReminder
    }
}