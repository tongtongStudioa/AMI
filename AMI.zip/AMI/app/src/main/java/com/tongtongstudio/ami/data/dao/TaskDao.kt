package com.tongtongstudio.ami.data.dao

import androidx.room.*
import com.tongtongstudio.ami.data.datatables.Task
import kotlinx.coroutines.flow.Flow

@Dao
interface TaskDao {

    @Query("SELECT * FROM task_table WHERE isTaskCompleted != :hideCompleted AND taskDeadline BETWEEN :startOfToday AND :endOfToday OR isTaskCompleted == 0 AND taskDeadline <= :endOfToday")
    fun getTodayTasks(
        hideCompleted: Boolean,
        startOfToday: Long,
        endOfToday: Long
    ): Flow<List<Task>>

    @Query("SELECT * FROM task_table WHERE isTaskCompleted == 0 AND taskDeadline > :endOfToday AND project_id IS NULL")
    fun getLaterTasks(endOfToday: Long): Flow<List<Task>>

    @Query("SELECT * FROM task_table WHERE isTaskCompleted == 0 AND taskDeadline BETWEEN :endOfToday AND :endOfDayFilter AND project_id IS NULL")
    fun getLaterTasksFilter(endOfToday: Long, endOfDayFilter: Long): Flow<List<Task>>

    @Query("SELECT * FROM task_table WHERE isTaskCompleted AND project_id IS NULL ORDER BY taskCompletedDate DESC")
    fun getAllCompletedTasks(): Flow<List<Task>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(task: Task): Long

    @Update
    suspend fun update(task: Task)

    @Delete
    suspend fun delete(task: Task)

    @Delete
    suspend fun deleteSubTasks(subTasks: List<Task>)

    @Insert(onConflict = OnConflictStrategy.IGNORE)
    suspend fun insertUndoDeletedSubTasks(listSubTasks: List<Task>)

    @Query("SELECT * FROM task_table WHERE isTaskCompleted")
    suspend fun getTasksCompletedStats(): List<Task>
}