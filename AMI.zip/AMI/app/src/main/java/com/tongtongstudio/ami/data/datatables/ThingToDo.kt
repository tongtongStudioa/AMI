package com.tongtongstudio.ami.data.datatables

import android.os.Parcelable
import androidx.room.Ignore
import kotlinx.android.parcel.Parcelize
import java.text.SimpleDateFormat

const val PATTERN_FORMAT_DATE = "E dd/MM"

@Parcelize
open class ThingToDo(
    // TODO: 09/02/2023 add "due date" in comparison to deadline
    @Ignore open val name: String,
    @Ignore val priority: Int,
    @Ignore val deadline: Long?,
    @Ignore val completedDate: String?
) : Parcelable {


    //@ColumnInfo(name = "protocol_repeatable") val protocolRepeatable: String? = null,
    /*open var estimatedTime: Long? //= null
    open var workTime: Long? //= null
    open var isCompleted: Boolean// = false
    open var completedDate: String? //= null
    open var reminder: Long?// = null
    open var createdDate: Long //= System.currentTimeMillis()*/
    open fun getCreatedDateFormatted(): String {
        return "no_date"
    }

    open fun getDeadline(): String? {
        return if (deadline != null) {
            SimpleDateFormat(PATTERN_FORMAT_DATE).format(deadline)
        } else null
    }

    open fun getEstimatedTime(): Long? {
        return 0
    }

    open fun getWorkTime(): Long? {
        return 0
    }

    open fun isCompleted(): Boolean {
        return false
    }

    open fun getReminder(): Long? {
        return 0
    }
}