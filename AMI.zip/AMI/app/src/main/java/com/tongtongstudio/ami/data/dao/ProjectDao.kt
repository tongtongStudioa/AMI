package com.tongtongstudio.ami.data.dao

import androidx.room.*
import com.tongtongstudio.ami.data.SortOrder
import com.tongtongstudio.ami.data.datatables.Project
import com.tongtongstudio.ami.data.datatables.ProjectWithSubTasks
import kotlinx.coroutines.flow.Flow

@Dao
interface ProjectDao {

    @Transaction
    @Query("SELECT * FROM project_table WHERE is_pjt_completed != :hideCompleted AND pjtDeadline BETWEEN :startOfToday AND :endOfToday OR is_pjt_completed == 0 AND pjtDeadline <= :endOfToday")
    fun getTodayProjects(
        hideCompleted: Boolean,
        startOfToday: Long,
        endOfToday: Long
    ): Flow<List<ProjectWithSubTasks>>

    @Transaction
    @Query("SELECT * FROM project_table WHERE is_pjt_completed == 0 AND pjtDeadline > :endOfToday ")
    fun getLaterProjects(endOfToday: Long): Flow<List<ProjectWithSubTasks>>

    @Transaction
    @Query("SELECT * FROM project_table WHERE is_pjt_completed == 0 AND pjtDeadline BETWEEN :endOfToday AND :endOfDayFilter")
    fun getLaterProjectsFilter(endOfToday: Long, endOfDayFilter: Long): Flow<List<ProjectWithSubTasks>>


    fun getProjectsWithTasks(
        sortOrder: SortOrder,
        hideCompleted: Boolean
    ): Flow<List<ProjectWithSubTasks>> =
        when (sortOrder) {
            SortOrder.BY_IMPORTANCE_PRIORITY -> getAllProjectsByPriority(hideCompleted)
            SortOrder.BY_DEADLINE -> getAllProjectsByDeadline(
                hideCompleted
            )
            SortOrder.BY_NAME -> getAllProjectsByName(hideCompleted)
        }

    @Transaction
    @Query("SELECT * FROM project_table WHERE (is_pjt_completed != :hideCompleted OR is_pjt_completed = 0) ORDER BY pjtName ")
    fun getAllProjectsByName(hideCompleted: Boolean): Flow<List<ProjectWithSubTasks>>

    @Transaction
    @Query("SELECT * FROM project_table WHERE (is_pjt_completed != :hideCompleted OR is_pjt_completed = 0) ORDER BY is_pjt_completed, pjtPriority DESC")
    fun getAllProjectsByPriority(hideCompleted: Boolean): Flow<List<ProjectWithSubTasks>>

    @Transaction
    @Query("SELECT * FROM project_table WHERE (is_pjt_completed != :hideCompleted OR is_pjt_completed = 0) ORDER BY pjtDeadline DESC")
    fun getAllProjectsByDeadline(hideCompleted: Boolean): Flow<List<ProjectWithSubTasks>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(project: Project): Long

    @Update
    suspend fun update(project: Project)

    @Delete
    suspend fun delete(project: Project)

    @Transaction
    @Query("SELECT * FROM project_table WHERE p_id = :projectId LIMIT 1")
    suspend fun getProject(projectId: Long): ProjectWithSubTasks

    @Transaction
    @Query("SELECT * FROM project_table WHERE is_pjt_completed ORDER BY pjtCompletedDate")
    fun getAllCompletedProjects(): Flow<List<ProjectWithSubTasks>>

    @Query("SELECT * FROM project_table")
    suspend fun getProjectsStats(): List<Project>
}