package com.tongtongstudio.ami.ui.achievements

import androidx.lifecycle.ViewModel
import com.tongtongstudio.ami.data.Repository
import com.tongtongstudio.ami.data.datatables.Project
import com.tongtongstudio.ami.data.datatables.Task
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.runBlocking
import java.text.DateFormat
import java.util.*
import javax.inject.Inject
import kotlin.math.abs

@HiltViewModel
class AchievementsViewModel @Inject constructor(
    private val repository: Repository,
) : ViewModel() {
    // todo : change method
    private val listTasksCompleted = retrieveTasksCompleted()
    private val listProjects = retrieveProjectCompletedRatio()

    val nbTaskCompleted = listTasksCompleted.size
    val nbProjectsCompleted = getProjectsCompleted()
    val taskAverageTimeCompletion = getAverageTimeCompletion()
    val projectsAchievementRate = getProjectAchievementRate()
    val onTimeCompletionRate = retrieveOnTimeCompletionRate()
    val estimationAccuracyRate = retrieveEstimationWorkTimeAccuracyRate()

    private fun getAverageTimeCompletion(): Long? {
        var sum = 0L
        var taskNoCount = 0
        listTasksCompleted.forEach {
            sum += if (it.taskWorkTime != null && it.taskWorkTime != 0L)
                it.taskWorkTime
            else {
                taskNoCount += 1
                0L
            }
        }
        return if (listTasksCompleted.isEmpty()) null else sum / (listTasksCompleted.size - taskNoCount)
    }

    private fun getProjectAchievementRate(): Double {
        var sumSubTasks = 0
        var sumSubTasksCompleted = 0
        listProjects.forEach {
            sumSubTasks += it.nb_sub_task
            sumSubTasksCompleted += it.nb_sub_tasks_completed
        }
        return if (sumSubTasksCompleted == 0) 0.0 else sumSubTasksCompleted.toDouble() / sumSubTasks.toDouble() * 100
    }

    private fun retrieveEstimationWorkTimeAccuracyRate(): Double {
        var tasksStudied = 0
        var rateSum = 0.0
        listTasksCompleted.forEach {
            val completionTime = it.taskWorkTime
            val estimatedTime = it.taskEstimatedTime //in minutes todo change this in millis

            if (completionTime != null && estimatedTime != null) {
                val estimatedTimeMillis = estimatedTime * 60 * 1000
                val difference = abs((completionTime - estimatedTimeMillis))
                rateSum += if (difference < 2 * estimatedTimeMillis) {
                    (1 - difference / estimatedTimeMillis).toDouble()
                } else 0.0
                tasksStudied += 1
            }
        }
        return if (listTasksCompleted.isEmpty()) 0.0 else rateSum / tasksStudied * 100
    }

    // TODO: 23/03/2023 change "completedDate" characteristic to long
    private fun retrieveOnTimeCompletionRate(): Double {
        var nbCompletedOnTime = 0
        listTasksCompleted.forEach {
            val calendar = Calendar.getInstance()
            DateFormat.getDateInstance().parse(it.taskCompletedDate!!).also { calendar.time = it!! }
            val completedDateInMillis = calendar.timeInMillis
            val completedOnTime: Boolean =
                abs(it.deadline!! - completedDateInMillis) < 24 * 60 * 60 * 1000 || completedDateInMillis < it.deadline // interval = one day in millis sec, maybe shrink out
            if (completedOnTime) nbCompletedOnTime++
        }
        return if (listTasksCompleted.isEmpty()) .0 else nbCompletedOnTime / listTasksCompleted.size.toDouble() * 100
    }

    private fun getProjectsCompleted(): Int {
        val projectCompleted = ArrayList<Project>()
        listProjects.forEach {
            if (it.isPjtCompleted) projectCompleted.add(it)
        }
        return projectCompleted.toList().size
    }

    private fun retrieveTasksCompleted() = runBlocking<List<Task>> {
        return@runBlocking repository.getTasksCompletedStats()
    }

    private fun retrieveProjectCompletedRatio() = runBlocking {
        return@runBlocking repository.getProjectCompletedStats()
    }
}
