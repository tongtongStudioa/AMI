package com.tongtongstudio.ami.data.datatables

import androidx.room.ColumnInfo
import androidx.room.Entity
import androidx.room.PrimaryKey
import kotlinx.parcelize.Parcelize
import java.text.DateFormat

@Parcelize
@Entity(tableName = "project_table")
data class Project(
    val pjtName: String,
    val pjtPriority: Int,
    val pjtDeadline: Long? = null,
    //@ColumnInfo(name = "protocol_repeatable") val protocolRepeatable: String? = null,
    @ColumnInfo(name = "pjt_estimated_time") val pjtEstimatedTime: Long? = null,
    @ColumnInfo(name = "pjt_work_time") val pjtWorkTime: Long? = null,
    @ColumnInfo(name = "is_pjt_completed") val isPjtCompleted: Boolean = false,
    val pjtCompletedDate: String? = null,
    val pjtReminder: Long? = null,
    // unique properties
    val nb_sub_task: Int = 0,
    val nb_sub_tasks_completed: Int = 0,
    // unique thing to do's id
    @PrimaryKey(autoGenerate = true) val p_id: Long = 0,
    @ColumnInfo(name = "pjt_created_date") val pjtCreatedDate: Long = System.currentTimeMillis()
) : ThingToDo(pjtName, pjtPriority, pjtDeadline, pjtCompletedDate) {
    override fun getCreatedDateFormatted(): String {
        return DateFormat.getDateInstance().format(pjtCreatedDate)
    }

    override fun getEstimatedTime(): Long? {
        return pjtEstimatedTime
    }

    override fun getWorkTime(): Long? {
        return pjtWorkTime
    }

    override fun isCompleted(): Boolean {
        return isPjtCompleted
    }

    override fun getReminder(): Long? {
        return pjtReminder
    }
}