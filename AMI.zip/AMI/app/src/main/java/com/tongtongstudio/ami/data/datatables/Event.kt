package com.tongtongstudio.ami.data.datatables

import androidx.room.ColumnInfo
import androidx.room.Entity
import androidx.room.PrimaryKey
import kotlinx.android.parcel.Parcelize
import java.text.DateFormat

@Parcelize
@Entity(tableName = "event_table")
data class Event(
    // shared properties by event, project and event class
    @ColumnInfo(name = "event_name") val eventName: String,
    @ColumnInfo(name = "event_priority") val eventPriority: Int,
    @ColumnInfo(name = "event_deadline") val eventDeadline: Long? = null,
    //@ColumnInfo(name = "is_recurring") val isRecurring: Boolean = false,
    //@ColumnInfo(name = "protocol_repeatable") val protocolRepeatable: String? = null,
    @ColumnInfo(name = "estimated_time") val eventEstimatedTime: Long? = null,
    @ColumnInfo(name = "work_time") val eventWorkTime: Long? = null,
    @ColumnInfo(name = "is_event_completed") val isEventCompleted: Boolean = false,
    //val completedDate: String? = null,
    @ColumnInfo(name = "event_reminder") val eventReminder: Long? = null,
    // unique properties
    @ColumnInfo(name = "beginning_date") val beginningDate: String? = null,
    @ColumnInfo(name = "is_spread") val isSpread: Boolean = false,
    @ColumnInfo(name = "ending_date") val endingDate: String? = beginningDate,
    // unique thing to do's id
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    @ColumnInfo(name = "created_date") val eventCreatedDate: Long = System.currentTimeMillis(),

    ) : ThingToDo(eventName, eventPriority, eventDeadline, null) {
    override fun getCreatedDateFormatted(): String {
        return DateFormat.getDateInstance().format(eventCreatedDate)
    }
}