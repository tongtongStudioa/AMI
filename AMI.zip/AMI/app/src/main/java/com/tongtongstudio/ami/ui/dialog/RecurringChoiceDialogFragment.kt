package com.tongtongstudio.ami.ui.dialog

import android.app.AlertDialog
import android.app.Dialog
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ArrayAdapter
import androidx.core.os.bundleOf
import androidx.fragment.app.DialogFragment
import androidx.fragment.app.setFragmentResult
import com.tongtongstudio.ami.R
import com.tongtongstudio.ami.databinding.DialogChooseRecurringProtocolBinding


const val DAY = "DAY"
const val WEEK = "WEEK"
const val MONTH = "MONTH"
const val YEAR = "YEAR"

class RecurringChoiceDialogFragment : DialogFragment() {

    private lateinit var binding: DialogChooseRecurringProtocolBinding

    override fun onCreateDialog(savedInstanceState: Bundle?): Dialog {
        return activity?.let {
            val builder = AlertDialog.Builder(it)
            // Get the layout inflater
            val inflater = requireActivity().layoutInflater
            binding = DialogChooseRecurringProtocolBinding.inflate(inflater)
            // Inflate and set the layout for the dialog
            // Pass null as the parent view because its going in the dialog layout
            builder.setView(binding.root)
                // Add action buttons
                .setPositiveButton(R.string.ok) { dialog, id ->
                    onDialogPositiveClick(this)
                }
                .setNegativeButton(
                    R.string.cancel
                ) { dialog, id ->
                    getDialog()?.cancel()
                }
            builder.create()
        } ?: throw IllegalStateException("Activity cannot be null")
    }

    private fun onDialogPositiveClick(dialog: RecurringChoiceDialogFragment) {
        val nDays: String =
            if (binding.inputLayoutUserChoice.editText?.text?.isNotEmpty() == true) {
                binding.inputLayoutUserChoice.editText?.text.toString()
            } else "1"
        val period: String = binding.autoCompleteTextView.text.toString()
        val result = "$nDays/$period"
        dialog.setFragmentResult(
            "recurring_choice_user",
            bundleOf("recurring_choice_result" to result)
        )
        dialog.dismiss()
    }

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        val items = resources.getStringArray(R.array.period_list)
        val adapter = ArrayAdapter(requireContext(), R.layout.list_options, items)
        binding.apply {
            autoCompleteTextView.setAdapter(adapter)
            autoCompleteTextView.setText(items[1], false)
        }
        return binding.root
    }
}