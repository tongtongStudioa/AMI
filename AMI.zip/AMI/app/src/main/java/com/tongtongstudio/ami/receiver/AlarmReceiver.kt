package com.tongtongstudio.ami.receiver

import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import com.tongtongstudio.ami.R
import com.tongtongstudio.ami.ui.MainActivity

const val TASK_CHANNEL_ID: String = "task_channel_id"
const val TTD_NAME: String = "thing_to_do_name"
const val TTD_DESCRIPTION: String = "thing_to_do_description"

class AlarmReceiver : BroadcastReceiver() {

    override fun onReceive(context: Context, intent: Intent) {

        // TODO: 09/07/2022 change this intent to go to timer of the task with link
        val intentDestination = Intent(context, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
        }
        val pendingIntent: PendingIntent =
            PendingIntent.getActivity(context, 0, intentDestination, 0)
        val ttdName = intent.getStringExtra(TTD_NAME)
        val descriptionNotification = intent.getStringExtra(TTD_DESCRIPTION)

        val builder = NotificationCompat.Builder(context, TASK_CHANNEL_ID)
            .setSmallIcon(R.mipmap.ic_launcher_simple_round)
            .setContentTitle(ttdName)
            .setContentText(descriptionNotification ?: "Description notification task")
            .setAutoCancel(true)
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setContentIntent(pendingIntent)

        with(NotificationManagerCompat.from(context)) {
            // notificationId is a unique int for each notification that you must define
            val notificationId = 1
            notify(notificationId, builder.build())
        }
    }
}