package com.tongtongstudio.ami.ui.monitoring.projectstats

import androidx.lifecycle.SavedStateHandle
import androidx.lifecycle.ViewModel
import com.tongtongstudio.ami.data.Repository
import com.tongtongstudio.ami.data.datatables.ProjectWithSubTasks
import dagger.hilt.android.lifecycle.HiltViewModel
import javax.inject.Inject

@HiltViewModel
class ProjectStatsViewModel @Inject constructor(
    val repository: Repository,
    private val state: SavedStateHandle
) : ViewModel() {
    private val projectData = state.get<ProjectWithSubTasks>("project")
    val workTime = projectData?.getWorkTime() ?: 0
}