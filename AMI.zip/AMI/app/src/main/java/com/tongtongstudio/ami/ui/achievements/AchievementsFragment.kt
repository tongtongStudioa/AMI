package com.tongtongstudio.ami.ui.achievements

import android.os.Bundle
import android.view.View
import androidx.fragment.app.Fragment
import androidx.fragment.app.viewModels
import androidx.navigation.fragment.findNavController
import androidx.navigation.ui.navigateUp
import androidx.navigation.ui.setupWithNavController
import com.tongtongstudio.ami.R
import com.tongtongstudio.ami.databinding.AchievementsFragmentBinding
import com.tongtongstudio.ami.ui.MainActivity
import com.tongtongstudio.ami.ui.MainViewModel
import dagger.hilt.android.AndroidEntryPoint
import java.text.SimpleDateFormat

@AndroidEntryPoint
class AchievementsFragment : Fragment(R.layout.achievements_fragment) {

    private val viewModel: AchievementsViewModel by viewModels()
    private lateinit var sharedViewModel: MainViewModel
    private lateinit var binding: AchievementsFragmentBinding

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        binding = AchievementsFragmentBinding.bind(view)

        setUpToolbar()

        // TODO: 23/03/2023 save nb tasks completed in database to save completed tasks deleted
        //  and easiest way to retrieve this data
        // and this list is only tasks list !!
        binding.tvNbTasksCompleted.text =
            getString(R.string.nb_tasks_completed, viewModel.nbTaskCompleted)
        binding.tvProjectsCompleted.text =
            getString(R.string.projects_completed_information, viewModel.nbProjectsCompleted)
        binding.tvAverageTimeCompletion.text = if (viewModel.taskAverageTimeCompletion != null) {
            val timeFormat =
                SimpleDateFormat("HH:mm:ss").format(viewModel.taskAverageTimeCompletion)
            getString(R.string.average_time_completion_information, timeFormat)
        } else getString(R.string.no_information)
        binding.tvProjectsAchievementRate.text = getString(
            R.string.projects_achievement_rate_information,
            viewModel.projectsAchievementRate
        )
        binding.tvEstimationTimeAccuracy.text = getString(
            R.string.estimation_time_accuracy_information,
            viewModel.estimationAccuracyRate
        )
        binding.tvOnRateCompletionTime.text =
            getString(R.string.on_time_completion_rate_information, viewModel.onTimeCompletionRate)
    }

    // function to set up toolbar with collapse toolbar and link to drawer layout
    private fun setUpToolbar() {
        val mainActivity = activity as MainActivity
        // imperative to see option menu and navigation icon (hamburger)
        mainActivity.setSupportActionBar(binding.toolbar)

        val navController = findNavController()
        // retrieve app bar configuration : see MainActivity.class
        val appBarConfiguration = mainActivity.appBarConfiguration

        // to set hamburger menu work and open drawer layout
        binding.toolbar.setupWithNavController(navController, appBarConfiguration)
        binding.toolbar.setNavigationOnClickListener {
            navController.navigateUp(appBarConfiguration)
        }
    }
}