package com.tongtongstudio.ami.ui

import android.app.Activity
import android.os.Bundle
import androidx.activity.viewModels
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.Toolbar
import androidx.drawerlayout.widget.DrawerLayout
import androidx.navigation.NavController
import androidx.navigation.findNavController
import androidx.navigation.fragment.NavHostFragment
import androidx.navigation.fragment.findNavController
import androidx.navigation.ui.AppBarConfiguration
import androidx.navigation.ui.navigateUp
import androidx.navigation.ui.setupWithNavController
import com.google.android.material.appbar.CollapsingToolbarLayout
import com.google.android.material.navigation.NavigationView
import com.tongtongstudio.ami.R
import dagger.hilt.android.AndroidEntryPoint


@AndroidEntryPoint
class MainActivity : AppCompatActivity() {

    private lateinit var navController: NavController
    lateinit var drawerLayout: DrawerLayout
    lateinit var appBarConfiguration: AppBarConfiguration
    lateinit var toolbar: Toolbar
    private lateinit var collapsingToolbarLayout: CollapsingToolbarLayout

    val viewModel: MainViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        //top app bar and drawer layout with nav ui
        //toolbar = findViewById(R.id.toolbar)
        //val appbarLayout = findViewById<AppBarLayout>(R.id.app_bar)
        //setSupportActionBar(toolbar) //set the toolbar
        //collapsingToolbarLayout = findViewById(R.id.collapse_toolbar)

        val navView = findViewById<NavigationView>(R.id.nav_view)
        val navHostFragment =
            supportFragmentManager.findFragmentById(R.id.nav_host_fragment) as NavHostFragment
        navController = navHostFragment.findNavController()
        drawerLayout = findViewById(R.id.drawer_layout)

        appBarConfiguration = AppBarConfiguration(
            setOf(
                R.id.todayTasksFragment,
                R.id.othersTasksFragment,
                R.id.achievementsFragment,
                R.id.completedThingToDoFragment,
            ), drawerLayout
        )

        navView.setupWithNavController(navController)
        //NavigationUI.setupWithNavController(toolbar, navController, appBarConfiguration)
        //collapsingToolbarLayout.setupWithNavController(toolbar,navController,drawerLayout)

    }

    override fun onSupportNavigateUp(): Boolean {
        val navController = findNavController(R.id.nav_host_fragment)
        return navController.navigateUp(appBarConfiguration) || super.onSupportNavigateUp()
    }
}

const val ADD_TASK_RESULT_OK = Activity.RESULT_FIRST_USER
const val ADD_PROJECT_RESULT_OK = Activity.RESULT_FIRST_USER + 1
const val ADD_EVENT_RESULT_OK = Activity.RESULT_FIRST_USER + 2
const val EDIT_TASK_RESULT_OK = Activity.RESULT_FIRST_USER + 3
const val EDIT_PROJECT_RESULT_OK = Activity.RESULT_FIRST_USER + 4
const val EDIT_EVENT_RESULT_OK = Activity.RESULT_FIRST_USER + 5

