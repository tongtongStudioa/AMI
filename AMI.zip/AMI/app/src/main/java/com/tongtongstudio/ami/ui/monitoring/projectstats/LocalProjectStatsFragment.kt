package com.tongtongstudio.ami.ui.monitoring.projectstats

import android.os.Bundle
import android.view.View
import androidx.fragment.app.Fragment
import androidx.fragment.app.viewModels
import androidx.navigation.fragment.findNavController
import androidx.navigation.ui.navigateUp
import androidx.navigation.ui.setupWithNavController
import com.tongtongstudio.ami.R
import com.tongtongstudio.ami.databinding.ProjectStatsFragmentBinding
import com.tongtongstudio.ami.ui.MainActivity
import dagger.hilt.android.AndroidEntryPoint
import java.text.SimpleDateFormat

@AndroidEntryPoint
class LocalProjectStatsFragment : Fragment(R.layout.project_stats_fragment) {
    lateinit var binding: ProjectStatsFragmentBinding
    private val viewModel: ProjectStatsViewModel by viewModels()

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        binding = ProjectStatsFragmentBinding.bind(view)

        setUpToolbar()

        binding.totalWorkTime.text =
            when {
                viewModel.workTime < 60 * 60 * 1000 -> getString(
                    R.string.project_total_work_time,
                    SimpleDateFormat("mm:ss").format(viewModel.workTime)
                )
                viewModel.workTime >= 60 * 60 * 1000 -> getString(
                    R.string.project_total_work_time,
                    SimpleDateFormat("hh:mm").format(viewModel.workTime)
                )
                else -> getString(R.string.no_information)
            }
    }

    // function to set up toolbar with collapse toolbar and link to drawer layout
    private fun setUpToolbar() {
        val mainActivity = activity as MainActivity
        // imperative to see option menu and navigation icon (hamburger)
        mainActivity.setSupportActionBar(binding.toolbar)

        val navController = findNavController()
        // retrieve app bar configuration : see MainActivity.class
        val appBarConfiguration = mainActivity.appBarConfiguration

        // to set hamburger menu work and open drawer layout
        binding.toolbar.setupWithNavController(navController, appBarConfiguration)
        binding.toolbar.setNavigationOnClickListener {
            navController.navigateUp(appBarConfiguration)
        }
    }
}