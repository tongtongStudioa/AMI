package com.tongtongstudio.ami.ui.addedittask

import android.app.*
import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.PopupMenu
import androidx.core.app.AlarmManagerCompat
import androidx.core.os.bundleOf
import androidx.core.util.Pair
import androidx.core.view.isVisible
import androidx.core.widget.addTextChangedListener
import androidx.fragment.app.Fragment
import androidx.fragment.app.setFragmentResult
import androidx.fragment.app.setFragmentResultListener
import androidx.fragment.app.viewModels
import androidx.lifecycle.lifecycleScope
import androidx.navigation.fragment.findNavController
import androidx.navigation.ui.navigateUp
import androidx.navigation.ui.setupWithNavController
import com.google.android.material.datepicker.MaterialDatePicker
import com.google.android.material.snackbar.Snackbar
import com.google.android.material.timepicker.MaterialTimePicker
import com.google.android.material.timepicker.TimeFormat
import com.tongtongstudio.ami.R
import com.tongtongstudio.ami.data.Nature
import com.tongtongstudio.ami.data.datatables.PATTERN_FORMAT_DATE
import com.tongtongstudio.ami.databinding.AddEditTaskFragmentBinding
import com.tongtongstudio.ami.receiver.AlarmReceiver
import com.tongtongstudio.ami.receiver.TASK_CHANNEL_ID
import com.tongtongstudio.ami.receiver.TTD_DESCRIPTION
import com.tongtongstudio.ami.receiver.TTD_NAME
import com.tongtongstudio.ami.ui.MainActivity
import com.tongtongstudio.ami.ui.dialog.RecurringChoiceDialogFragment
import com.tongtongstudio.todolistami.util.exhaustive
import dagger.hilt.android.AndroidEntryPoint
import kotlinx.coroutines.InternalCoroutinesApi
import java.text.DateFormat
import java.text.SimpleDateFormat
import java.util.*

@AndroidEntryPoint
class AddEditTaskFragment : Fragment(R.layout.add_edit_task_fragment) {

    private val viewModel: AddEditTaskViewModel by viewModels()

    private lateinit var binding: AddEditTaskFragmentBinding

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        createNotificationChannel()
        return super.onCreateView(inflater, container, savedInstanceState)
    }

    // TODO: 11/07/2022 reformat code with function for readability
    @InternalCoroutinesApi
    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        binding = AddEditTaskFragmentBinding.bind(view)

        // set toolbar with menu and navigate up icon
        setUpToolbar()

        binding.apply {
            editTextTaskName.setText(viewModel.name)

            radioGroupChoiceNature.check(
                when (viewModel.ttdNature) {
                    Nature.PROJECT.name -> {
                        rbProject.id
                    }
                    Nature.EVENT.name -> {
                        rbEvent.id
                    }
                    Nature.TASK.name -> {
                        rbTask.id
                    }
                    else -> rbTask.id
                }
            )
            radioGroupChoiceNature.jumpDrawablesToCurrentState()
            switchIsSpreadEvent.isChecked = viewModel.eventIsSpread
            showElementsCategories()
            editImportancePriority.editText?.setText(viewModel.priority.replace("null", ""))
            btnPickDateForDeadline.text =
                if (viewModel.deadline != null) getStringFromLong(viewModel.deadline!!) else "Add deadline"
            textViewDateCreated.isVisible = viewModel.thingToDo != null
            textViewDateCreated.text = if (viewModel.createdDateFormatted != null)
                getString(R.string.text_created_date, viewModel.createdDateFormatted) else ""

            editTextTaskName.addTextChangedListener {
                val name = it.toString()
                viewModel.name = if (name != "") name.replaceFirst(
                    name.first(),
                    name.first().uppercaseChar()
                ) else ""
            }
            editImportancePriority.editText?.addTextChangedListener {
                viewModel.priority = if (it.toString() == "null") "" else it.toString()
            }
            editTextEstimatedTime.editText?.setText(
                if (viewModel.estimatedTime == 0L)
                    ""
                else
                    viewModel.estimatedTime.toString()
            )
            editTextEstimatedTime.editText?.addTextChangedListener {
                val minutes = it.toString()
                viewModel.estimatedTime = if (minutes == "") null else minutes.toLong()
            }

            btnReminder.text = if (viewModel.reminder != null) DateFormat.getDateInstance()
                .format(viewModel.reminder!!)
            else getString(R.string.reminder_text_view_hint)
            // TODO: 31/05/2022 work with nav component
            val dropDownMenu = PopupMenu(context, btnPickDateForDeadline)
            btnPickDateForDeadline.setOnClickListener {
                dropDownMenu.show()
            }

            dropDownMenu.menuInflater.inflate(R.menu.popup_menu_date_picker, dropDownMenu.menu)
            dropDownMenu.setOnMenuItemClickListener {
                when (it.itemId) {
                    R.id.action_today -> {
                        val todayDate = Calendar.getInstance().time
                        val todayFormatted = getStringFromLong(todayDate.time)
                        viewModel.deadline = todayDate.time
                        btnPickDateForDeadline.text = todayFormatted
                        true
                    }
                    R.id.action_tomorrow -> {
                        val tomorrowDate = Calendar.getInstance().run {
                            add(Calendar.DAY_OF_MONTH, 1)
                            time
                        }
                        val tomorrowFormatted = getStringFromLong(tomorrowDate.time)
                        viewModel.deadline = tomorrowDate.time
                        btnPickDateForDeadline.text = tomorrowFormatted
                        true
                    }
                    R.id.action_personalized -> {
                        pickUserDate(viewModel.deadline)
                        true
                    }
                    else -> true
                }
            }

            btnReminder.setOnClickListener {
                var reminderTriggerTime = 0L
                val datePicker = showDatePickerMaterial(viewModel.deadline)

                datePicker.addOnPositiveButtonClickListener {
                    val date = Date(it)
                    val cal = Calendar.getInstance()
                    cal.time = date
                    val timePicker = showTimePickerMaterial(MaterialTimePicker.INPUT_MODE_CLOCK)

                    timePicker.addOnPositiveButtonClickListener {
                        val pickedHour = timePicker.hour
                        val pickedMinutes = timePicker.minute
                        cal.set(Calendar.HOUR_OF_DAY, pickedHour)
                        cal.set(Calendar.MINUTE, pickedMinutes)
                        reminderTriggerTime = cal.timeInMillis

                        viewModel.reminder = reminderTriggerTime
                        binding.btnReminder.text =
                            DateFormat.getDateTimeInstance().format(reminderTriggerTime)
                    }
                }

            }

            val dropDownMenuRepeat = PopupMenu(requireContext(), acTextViewRepeatable)
            acTextViewRepeatable.setOnFocusChangeListener { v, hasFocus ->
                if (hasFocus) dropDownMenuRepeat.show()
            }

            dropDownMenuRepeat.menuInflater.inflate(
                R.menu.popup_menu_repeatable,
                dropDownMenuRepeat.menu
            )
            dropDownMenuRepeat.setOnMenuItemClickListener {
                when (it.itemId) {
                    R.id.action_every_day -> {
                        // TODO: 31/03/2023 change protocol string
                        val recurringInfo = viewModel.onRecurringChoiceResult("1/Day")
                        acTextViewRepeatable.setText(showPeriodRecurringTask(recurringInfo))
                        true
                    }
                    R.id.action_every_week -> {
                        val recurringInfo = viewModel.onRecurringChoiceResult("1/Week")
                        acTextViewRepeatable.setText(showPeriodRecurringTask(recurringInfo))
                        true
                    }
                    R.id.action_personalized -> {
                        showRepeatableCyclePicker()
                        true
                    }
                    else -> true
                }
            }

            if (viewModel.protocolRepeatable != null) {
                acTextViewRepeatable.setText(
                    showPeriodRecurringTask(
                        viewModel.onRecurringChoiceResult(
                            viewModel.protocolRepeatable
                        )
                    )
                )
            }
            inputLayoutRepeatable.setEndIconOnClickListener {
                acTextViewRepeatable.setText(showPeriodRecurringTask(null))
            }
            radioGroupChoiceNature.setOnCheckedChangeListener { _, checkedId ->
                when (checkedId) {
                    rbEvent.id -> {
                        btnPickDateForDeadline.isVisible = true
                        editImportancePriority.isVisible = true
                        switchIsSpreadEvent.isVisible = true
                        acTextViewRepeatable.isVisible = false
                    }
                    rbTask.id -> {
                        btnPickDateForDeadline.isVisible = true
                        editImportancePriority.isVisible = true
                        btnPickDateForEvent.isVisible = false
                        switchIsSpreadEvent.isVisible = false
                        acTextViewRepeatable.isVisible = true
                    }
                    rbProject.id -> {
                        btnPickDateForDeadline.isVisible = true
                        editImportancePriority.isVisible = true
                        btnPickDateForEvent.isVisible = false
                        switchIsSpreadEvent.isVisible = false
                        acTextViewRepeatable.isVisible = false
                    }
                }
                viewModel.radioBtnCheckedChange(checkedId)
            }

            // TODO: 09/02/2023 change format date database
            btnPickDateForEvent.setOnClickListener {
                if (switchIsSpreadEvent.isChecked) {
                    val dateRangePicker = showDateRangePickerMaterial()
                    dateRangePicker.addOnPositiveButtonClickListener {
                        val beginningDate: Long = it.first!!
                        val endingDate: Long = it.second!!

                        viewModel.eventBeginningDate =
                            DateFormat.getDateInstance().format(beginningDate)
                        viewModel.eventEndingDate = DateFormat.getDateInstance().format(endingDate)
                    }
                } else {
                    pickUserDate(null)
                }
            }

            fabSaveTask.setOnClickListener {
                safeSave()
            }
            setFragmentResultListener("recurring_choice_user") { _, bundle ->
                val result = bundle.getString("recurring_choice_result")
                val recurringCodeList = viewModel.onRecurringChoiceResult(result)
                acTextViewRepeatable.setText(showPeriodRecurringTask(recurringCodeList))
            }
        }

        setFragmentResultListener("is_new_sub_task") { _, bundle ->
            val result = bundle.getLong("project_id")
            viewModel.projectId = result
        }

        viewLifecycleOwner.lifecycleScope.launchWhenStarted {
            viewModel.addEditTaskEvent.collect { event ->
                when (event) {
                    is AddEditTaskViewModel.AddEditTaskEvent.ShowInvalidInputMessage -> {
                        Snackbar.make(requireView(), event.msg, Snackbar.LENGTH_LONG).show()
                    }
                    is AddEditTaskViewModel.AddEditTaskEvent.NavigateBackWithResult -> {
                        binding.editTextTaskName.clearFocus()
                        setFragmentResult(
                            "add_edit_request",
                            bundleOf("add_edit_result" to event.result)
                        )
                        findNavController().popBackStack()
                    }
                    /*is AddEditTaskViewModel.AddEditTaskEvent.NavigatePickerDateScreen -> {
                            val action = AddEditTaskFragmentDirections.actionGlobalDatePickerDialogFragment()
                            findNavController().navigate(action)
                        }*/
                }.exhaustive
            }
        }
    }

    // TODO: 11/02/2023 delete this method to free up space
    private fun getStringFromLong(long: Long): String {
        return SimpleDateFormat(PATTERN_FORMAT_DATE).format(long)
    }

    private fun pickUserDate(deadline: Long?) {
        val datePicker = showDatePickerMaterial(deadline)
        datePicker.addOnPositiveButtonClickListener {
            val dateFormatted = getStringFromLong(it)
            viewModel.eventBeginningDate = dateFormatted
            viewModel.eventEndingDate = dateFormatted
            viewModel.deadline = it
            binding.btnPickDateForDeadline.text = dateFormatted
        }// TODO: 31/03/2023 what the hell ? ^ and \/
        if (viewModel.deadline != null) {
            binding.btnPickDateForDeadline.text = getStringFromLong(viewModel.deadline!!)
        }
    }

    private fun safeSave() {
        if (viewModel.name.isBlank()) {
            viewModel.showInvalidInputMessage(getString(R.string.error_no_name))
            return
        } else if (viewModel.priority.isBlank() || viewModel.priority == "null" || viewModel.priority == "0") {
            viewModel.showInvalidInputMessage(getString(R.string.error_no_priority))
            return
        } else if ((viewModel.eventEndingDate == null && viewModel.eventBeginningDate == null) && viewModel.deadline == null) {
            viewModel.showInvalidInputMessage(getString(R.string.error_no_deadline))
            return
        }
        engageReminder(viewModel.reminder)
        viewModel.onSaveClick()
    }

    private fun engageReminder(timeReminder: Long?) {
        if (timeReminder != null) {
            val alarmManager =
                activity?.application?.getSystemService(Application.ALARM_SERVICE) as AlarmManager
            val notifyIntent = Intent(context, AlarmReceiver::class.java).apply {
                putExtra(TTD_NAME, viewModel.name)
                putExtra(TTD_DESCRIPTION, getStringFromLong(viewModel.deadline!!))
            }
            val notifyPendingIntent =
                PendingIntent.getBroadcast(context, 0, notifyIntent, 0)
            val intervalInMillis: Long =
                (1000 * 60 * 60 * 48).toLong() // TODO: 25/10/2022 change this interval to fit with interval in days, weeks, months or years
            if (viewModel.isRecurring) {
                alarmManager.setRepeating(
                    AlarmManager.RTC_WAKEUP,
                    timeReminder,
                    intervalInMillis,
                    notifyPendingIntent
                )
            } else {
                AlarmManagerCompat.setExact(
                    alarmManager,
                    AlarmManager.RTC_WAKEUP,
                    timeReminder,
                    notifyPendingIntent
                )
            }
        }
    }

    private fun showElementsCategories() {
        binding.apply {
            when {
                rbEvent.isChecked -> {
                    btnPickDateForDeadline.isVisible = true
                    editImportancePriority.isVisible = true
                    switchIsSpreadEvent.isVisible = true
                    acTextViewRepeatable.isVisible = false
                    inputLayoutRepeatable.isVisible = false
                }
                rbProject.isChecked -> {
                    btnPickDateForDeadline.isVisible = true
                    editImportancePriority.isVisible = true
                    btnPickDateForEvent.isVisible = false
                    switchIsSpreadEvent.isVisible = false
                    acTextViewRepeatable.isVisible = false
                }
                rbTask.isChecked -> {
                    btnPickDateForDeadline.isVisible = true
                    editImportancePriority.isVisible = true
                    btnPickDateForEvent.isVisible = false
                    switchIsSpreadEvent.isVisible = false
                    acTextViewRepeatable.isVisible = true
                }
            }
        }
    }

    private fun showRepeatableCyclePicker() {
        val newFragment = RecurringChoiceDialogFragment()
        newFragment.show(parentFragmentManager, "recurring_choice")
    }

    private fun showPeriodRecurringTask(codeList: List<String>?): String {
        val recurringInfo: String
        val arrayStringPeriod = resources.getStringArray(R.array.period_list)
        if (codeList != null) {
            if (codeList[0] == "1") {
                recurringInfo = when (codeList[1]) {
                    arrayStringPeriod[0] -> getString(R.string.each_days)
                    arrayStringPeriod[1] -> getString(R.string.each_weeks)
                    arrayStringPeriod[2] -> getString(R.string.each_months)
                    arrayStringPeriod[3] -> getString(R.string.each_years)
                    else -> getString(R.string.each_days)
                }
            } else {
                recurringInfo = when (codeList[1]) {
                    arrayStringPeriod[0] -> getString(R.string.every_x_days, codeList[0])
                    arrayStringPeriod[1] -> getString(R.string.every_x_weeks, codeList[0])
                    arrayStringPeriod[2] -> getString(R.string.every_x_months, codeList[0])
                    arrayStringPeriod[3] -> getString(R.string.every_x_years, codeList[0])
                    else -> getString(R.string.every_x_days, codeList[0])
                }
            }
        } else {
            recurringInfo = getString(R.string.repeat_text)
        }
        return recurringInfo
    }

    private fun showDatePickerMaterial(selection: Long?): MaterialDatePicker<Long> {
        viewModel.eventIsSpread = false
        val datePicker =
            MaterialDatePicker.Builder.datePicker()
                .setTitleText(getString(R.string.select_date))
                .setSelection(selection ?: MaterialDatePicker.todayInUtcMilliseconds())
                .build()
        datePicker.show(parentFragmentManager, "datePicker")

        return datePicker
    }

    private fun showTimePickerMaterial(inputMode: Int): MaterialTimePicker {
        val timePicker =
            MaterialTimePicker.Builder()
                .setTitleText("Select Time Reminder")
                .setTimeFormat(TimeFormat.CLOCK_24H)
                .setHour(9)
                .setMinute(30)
                .setInputMode(inputMode)
                .build()
        timePicker.show(parentFragmentManager, "timePicker")

        return timePicker
    }

    private fun showDateRangePickerMaterial(): MaterialDatePicker<Pair<Long, Long>> {
        viewModel.eventIsSpread = true
        val dateRangePicker =
            MaterialDatePicker.Builder.dateRangePicker()
                .setTitleText(getString(R.string.Select_two_date_to_spread_event))
                .build()
        dateRangePicker.show(parentFragmentManager, "dateRangePicker")

        return dateRangePicker
    }

    private fun createNotificationChannel() {
        // Create the NotificationChannel, but only on API 26+ because
        // the NotificationChannel class is new and not in the support library
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val name = getString(R.string.title_notification_channel)
            val descriptionText = getString(R.string.description_notification_channel)
            val importance = NotificationManager.IMPORTANCE_HIGH
            val channel = NotificationChannel(TASK_CHANNEL_ID, name, importance).apply {
                description = descriptionText
            }
            // Register the channel with the system
            val notificationManager: NotificationManager =
                requireActivity().getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            notificationManager.createNotificationChannel(channel)
        }
    }

    // function to set up toolbar with collapse toolbar and link to drawer layout
    private fun setUpToolbar() {
        val mainActivity = activity as MainActivity
        // imperative to see option menu and navigation icon (hamburger)
        mainActivity.setSupportActionBar(binding.toolbar)

        val navController = findNavController()
        // retrieve app bar configuration : see MainActivity.class
        val appBarConfiguration = mainActivity.appBarConfiguration

        // to set hamburger menu work and open drawer layout
        binding.toolbar.setupWithNavController(navController, appBarConfiguration)
        binding.toolbar.setNavigationOnClickListener {
            navController.navigateUp(appBarConfiguration)
        }
    }
}