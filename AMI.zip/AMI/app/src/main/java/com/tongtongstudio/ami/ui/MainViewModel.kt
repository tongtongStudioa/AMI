package com.tongtongstudio.ami.ui

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.tongtongstudio.ami.data.LaterFilter
import com.tongtongstudio.ami.data.PreferencesManager
import com.tongtongstudio.ami.data.Repository
import com.tongtongstudio.ami.data.SortOrder
import com.tongtongstudio.ami.data.datatables.Event
import com.tongtongstudio.ami.data.datatables.ProjectWithSubTasks
import com.tongtongstudio.ami.data.datatables.Task
import com.tongtongstudio.ami.data.datatables.ThingToDo
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.channels.Channel
import kotlinx.coroutines.flow.receiveAsFlow
import kotlinx.coroutines.launch
import java.text.DateFormat
import java.util.*
import javax.inject.Inject

@HiltViewModel
class MainViewModel @Inject constructor(
    private val repository: Repository,
    private val preferencesManager: PreferencesManager
) : ViewModel() {

    private val mainEventChannel = Channel<SharedEvent>()
    val mainEvent = mainEventChannel.receiveAsFlow()

    //val preferencesFlow = preferencesManager.preferencesFlow

    fun onSortOrderSelected(sortOrder: SortOrder) = viewModelScope.launch {
        preferencesManager.updateSortOrder(sortOrder)
    }

    fun onHideCompletedClick(hideCompleted: Boolean) = viewModelScope.launch {
        preferencesManager.updateHideCompleted(hideCompleted)
    }

    fun onLaterFilterSelected(laterFilter: LaterFilter) = viewModelScope.launch {
        preferencesManager.updateLaterFilter(laterFilter)
    }

    fun onCheckBoxChanged(thingToDo: ThingToDo, checked: Boolean) = viewModelScope.launch {
        when (thingToDo) {
            is Task -> updateTask(thingToDo, checked)
        }
    }

    private fun updateEvent() {
        TODO("Not yet implemented")
    }

    private fun updateProjectAdvancement(projectData: ProjectWithSubTasks) = viewModelScope.launch {
        val projectLinked = projectData.project

        //adapt if the all project is completed and nb sub task completed
        var nbSubTasksCompleted = 0
        for (task in projectData.subTasks) {
            if (task.isTaskCompleted) {
                nbSubTasksCompleted++
            }
        }
        when {
            nbSubTasksCompleted == projectLinked.nb_sub_task -> {
                val completedDateString = DateFormat.getDateInstance(DateFormat.MEDIUM)
                    .format(Calendar.getInstance().time)
                repository.updateProject(
                    projectLinked.copy(
                        isPjtCompleted = true,
                        nb_sub_tasks_completed = nbSubTasksCompleted,
                        pjtCompletedDate = completedDateString // TODO: 31/03/2023 change dateString to Long for accountability like task
                    )
                )
            }
            projectLinked.isPjtCompleted -> {
                repository.updateProject(
                    projectLinked.copy(
                        isPjtCompleted = false,
                        nb_sub_tasks_completed = nbSubTasksCompleted,
                        pjtCompletedDate = null
                    )
                )
            }
            else -> repository.updateProject(projectLinked.copy(nb_sub_tasks_completed = nbSubTasksCompleted))
        }
    }

    private suspend fun updateTask(task: Task, checked: Boolean) {
        val cloneTask: Task
        if (task.isRecurring && task.taskDeadline != null && task.protocolRepeatable != null) {
            val protocolList = task.protocolRepeatable.split("/")
            val newDeadlineDate = Calendar.getInstance().run {
                timeInMillis = task.deadline!!
                when (protocolList[1]) {
                    "Day" -> add(Calendar.DAY_OF_MONTH, protocolList[0].toInt() * 1)
                    "Week" -> add(Calendar.DAY_OF_MONTH, protocolList[0].toInt() * 7)
                    "Month" -> add(Calendar.MONTH, protocolList[0].toInt() * 1)
                    "Year" -> add(Calendar.YEAR, protocolList[0].toInt() * 1)
                    else -> add(Calendar.DAY_OF_MONTH, 0)
                }
                time
            }
            val newDeadline = newDeadlineDate.time
            val isCompleted = if (checked) 1 else 0
            // TODO: 25/10/2022 how dismiss a miss check ? how count when task were completed or not ?

            val currentStreak = if (task.deadline == (newDeadline - 24 * 60 * 60 * 1000)) {
                task.nbCycle + 1
            } else 0
            cloneTask = task.copy(
                isTaskCompleted = false,
                taskDeadline = newDeadline,
                nbCompleted = task.nbCompleted + isCompleted,
                nbCycle = currentStreak
            )
            repository.updateTask(cloneTask)
        } else if (checked) {
            val completedDateString =
                DateFormat.getDateInstance(DateFormat.MEDIUM).format(Calendar.getInstance().time)
            cloneTask = task.copy(
                isTaskCompleted = true,
                taskCompletedDate = completedDateString
            )
        } else {
            cloneTask = task.copy(
                isTaskCompleted = false,
                taskCompletedDate = null
            )
        }
        repository.updateTask(cloneTask)
        // adapt advancement project after adapt task
        if (cloneTask.projectId != null) {
            val projectLinked = repository.getProjectData(cloneTask.projectId)
            updateProjectAdvancement(projectLinked)
        }
    }

    // TODO: 06/09/2022 change this method to show resource string
    fun onThingToDoRightSwiped(thingToDo: ThingToDo) = viewModelScope.launch {
        var textShow = ""
        when (thingToDo) {
            is Task -> {
                repository.deleteTask(thingToDo)
                if (thingToDo.projectId != null) {
                    val projectData = repository.getProjectData(thingToDo.projectId)
                    val projectLinked = projectData.project
                    val isSubTaskCompleted = if (thingToDo.isTaskCompleted) 1 else 0
                    repository.updateProject(
                        projectLinked.copy(
                            nb_sub_tasks_completed = projectLinked.nb_sub_tasks_completed - isSubTaskCompleted,
                            nb_sub_task = projectLinked.nb_sub_task - 1
                        )
                    )
                }
                textShow = "Task deleted"
            }
            is ProjectWithSubTasks -> {
                repository.deleteProject(thingToDo.project)
                repository.deleteSubTasks(thingToDo.subTasks)
                textShow = "Project deleted"
            }
            is Event -> {
                repository.deleteEvent(thingToDo)
                textShow = "Event deleted"
            }
        }
        mainEventChannel.send(
            SharedEvent.ShowUndoDeleteTaskMessage(
                textShow,
                thingToDo
            )
        )
    }

    fun onThingToDoLeftSwiped(thingToDo: ThingToDo) = viewModelScope.launch {
        mainEventChannel.send(SharedEvent.NavigateToEditScreen(thingToDo))
    }

    fun onAddThingToDoDemand() = viewModelScope.launch {
        mainEventChannel.send(SharedEvent.NavigateToAddScreen)
    }

    fun onAddEditResult(result: Int, stringsAdded: Array<String>, stringsUpdated: Array<String>) {
        when (result) {
            ADD_TASK_RESULT_OK -> showThingToDoSavedConfirmationMessage(stringsAdded[0])
            ADD_EVENT_RESULT_OK -> showThingToDoSavedConfirmationMessage(stringsAdded[1])
            ADD_PROJECT_RESULT_OK -> showThingToDoSavedConfirmationMessage(stringsAdded[2])
            EDIT_TASK_RESULT_OK -> showThingToDoSavedConfirmationMessage(stringsUpdated[0])
            EDIT_PROJECT_RESULT_OK -> showThingToDoSavedConfirmationMessage(stringsUpdated[0])
            EDIT_EVENT_RESULT_OK -> showThingToDoSavedConfirmationMessage(stringsUpdated[0])
        }
    }

    fun onUndoDeleteClick(thingToDo: ThingToDo) = viewModelScope.launch {
        when (thingToDo) {
            is ProjectWithSubTasks -> {
                repository.insertProject(thingToDo.project.copy())
                thingToDo.subTasks.forEach {
                    repository.insertTask(it.copy())
                }
            }
            is Task -> {
                repository.insertTask(thingToDo.copy())
            }
            is Event -> {
                repository.insertEvent(thingToDo.copy())
            }
        }
    }

    private fun showThingToDoSavedConfirmationMessage(text: String) = viewModelScope.launch {
        mainEventChannel.send(SharedEvent.ShowTaskSavedConfirmationMessage(text))
    }

    fun onSubTaskLeftSwiped(subTask: Task) = viewModelScope.launch {
        mainEventChannel.send(SharedEvent.NavigateToEditScreen(subTask))
    }

    fun onSubTaskRightSwiped(subTask: Task) = viewModelScope.launch {
        repository.deleteTask(subTask)
        if (subTask.projectId != null) {
            val projectData = repository.getProjectData(subTask.projectId)
            val projectLinked = projectData.project
            val isSubTaskCompleted = if (subTask.isTaskCompleted) 1 else 0
            repository.updateProject(
                projectLinked.copy(
                    nb_sub_tasks_completed = projectLinked.nb_sub_tasks_completed - isSubTaskCompleted,
                    nb_sub_task = projectLinked.nb_sub_task - 1
                )
            )
            updateProjectAdvancement(projectData)
        }
        mainEventChannel.send(SharedEvent.ShowUndoDeleteTaskMessage("Sub task deleted", subTask))
    }

    fun checkRecurrentTaskLate(listTasks: List<Task>) = viewModelScope.launch {
        val todayDate = Calendar.getInstance().time
        val todayDateFormatted =
            DateFormat.getDateInstance(DateFormat.MEDIUM).format(todayDate)
        for (task in listTasks) {
            if (task.taskDeadline != null && task.isRecurring && task.taskDeadline < todayDate.time) {
                do {
                    updateTask(task, false)
                } while (task.taskDeadline < todayDate.time)
            }
        }
    }

    fun onThingToDoClicked(thingToDo: ThingToDo) = viewModelScope.launch {
        when (thingToDo) {
            is Task -> mainEventChannel.send(SharedEvent.NavigateToTrackingScreen(thingToDo))
            is ProjectWithSubTasks -> mainEventChannel.send(
                SharedEvent.NavigateToLocalProjectStatsScreen(
                    thingToDo
                )
            )
        }
    }

    sealed class SharedEvent {
        data class NavigateToEditScreen(val thingToDo: ThingToDo) : SharedEvent()
        object NavigateToAddScreen : SharedEvent()
        data class NavigateToTrackingScreen(val task: Task) :
            SharedEvent()

        data class NavigateToLocalProjectStatsScreen(val projectData: ProjectWithSubTasks) :
            SharedEvent()

        data class ShowTaskSavedConfirmationMessage(val msg: String) : SharedEvent()
        data class ShowUndoDeleteTaskMessage(val textShow: String, val thingToDo: ThingToDo) :
            SharedEvent()
    }
}
