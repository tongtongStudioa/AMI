package com.tongtongstudio.ami.ui.adapter

import com.tongtongstudio.ami.data.datatables.ProjectWithSubTasks
import com.tongtongstudio.ami.data.datatables.Task
import com.tongtongstudio.ami.data.datatables.ThingToDo

interface ThingToDoListener {
    fun onItemThingToDoClicked(thingToDo: ThingToDo)

    fun onCheckBoxClick(task: Task, isChecked: Boolean)
    fun onItemTaskSwiped(subTask: Task, dir: Int)

    //fun onItemEventSwiped(event: Event, dir: Int)
    //fun onItemEventClicked(event: Event)

    //fun onItemProjectSwiped(project: ProjectWithSubTasks, dir: Int)
    //fun onItemProjectClicked(projectWithSubTasks: ProjectWithSubTasks)
    fun onProjectBtnAddSubTaskClicked(projectData: ProjectWithSubTasks)
}