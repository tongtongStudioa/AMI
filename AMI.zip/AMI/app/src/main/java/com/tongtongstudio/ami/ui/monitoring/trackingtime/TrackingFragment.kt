package com.tongtongstudio.ami.ui.monitoring.trackingtime

import android.media.AudioAttributes
import android.media.AudioManager
import android.media.SoundPool
import android.os.Build
import android.os.Bundle
import android.os.SystemClock
import android.view.View
import android.widget.Chronometer
import androidx.core.view.isVisible
import androidx.fragment.app.Fragment
import androidx.fragment.app.viewModels
import androidx.navigation.fragment.findNavController
import androidx.navigation.ui.navigateUp
import androidx.navigation.ui.setupWithNavController
import com.google.android.material.snackbar.Snackbar
import com.tongtongstudio.ami.R
import com.tongtongstudio.ami.databinding.ChronometerFragmentBinding
import com.tongtongstudio.ami.ui.MainActivity
import dagger.hilt.android.AndroidEntryPoint

@AndroidEntryPoint
class TrackingFragment : Fragment(R.layout.chronometer_fragment) {

    lateinit var binding: ChronometerFragmentBinding
    private val viewModel: TrackingViewModel by viewModels()
    lateinit var chronometer: Chronometer
    private lateinit var soundPool: SoundPool
    var soundID: Int = 0

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        binding = ChronometerFragmentBinding.bind(view)

        setUpToolbar()
        chronometer = binding.chronometer

        chronometer.base = SystemClock.elapsedRealtime() - viewModel.timerCount

        // sound pool for chronometer
        soundPool = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            val audioAttributes = AudioAttributes.Builder()
                .setUsage(AudioAttributes.USAGE_ASSISTANCE_SONIFICATION)
                .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                .build()
            SoundPool.Builder()
                .setMaxStreams(1)
                .setAudioAttributes(audioAttributes)
                .build()
        } else {
            SoundPool(6, AudioManager.STREAM_MUSIC, 0)
        }
        soundID = soundPool.load(this.context, R.raw.success_1,1)

        // binding elements layout
        binding.apply {
            txtViewTimeEstimated.text = if (viewModel.retrieveEstimatedTime() != null)
                getString(R.string.minutes_estimated, viewModel.retrieveEstimatedTime())
            else getString(R.string.no_estimated_work_time)

            tvNbCompleted.text = if (viewModel.nbCompleted != null) getString(
                R.string.times_completed,
                viewModel.nbCompleted
            )
            else getString(R.string.no_information)
            binding.tvStreak.text =
                if (viewModel.nbCompleted != null) getString(R.string.maximum_streak, viewModel.streak)
                else ""

            fabPlay.setOnClickListener {
                if (viewModel.isTimerRunning) {
                    onPauseClicked()
                } else onPlayClicked()
            }
            fabStop.setOnClickListener {
                onFabStopClicked()
            }

            val estimatedTime = viewModel.retrieveEstimatedTime()
            var haveBeenPlayed: Boolean = false
            if (estimatedTime != null && estimatedTime != 0L && viewModel.timerCount < estimatedTime * 60 * 1000) {
                val beginningBase = chronometer.base
                chronometer.setOnChronometerTickListener {
                    if (viewModel.timerCount + it.base - beginningBase > estimatedTime * 60 * 1000 && !haveBeenPlayed)
                        haveBeenPlayed = playAlertSound()
                }
            }
        }
    }

    private fun onFabStopClicked() {
        chronometer.stop()
        chronometer.base = SystemClock.elapsedRealtime()
        viewModel.timerCount = 0
        viewModel.isTimerRunning = false

        binding.fabPlay.setImageResource(R.drawable.ic_play_arrow)
    }

    private fun onPlayClicked() {
        chronometer.base = SystemClock.elapsedRealtime() - viewModel.timerCount
        chronometer.start()
        viewModel.isTimerRunning = true

        binding.fabStop.isVisible = false
        binding.fabPlay.setImageResource(R.drawable.ic_pause)
    }

    private fun onPauseClicked() {
        chronometer.stop()
        viewModel.saveTrackingTime(SystemClock.elapsedRealtime() - chronometer.base)
        viewModel.isTimerRunning = false

        binding.fabStop.isVisible = true
        binding.fabPlay.setImageResource(R.drawable.ic_play_arrow)
        Snackbar.make(requireView(), "Work time saved", Snackbar.LENGTH_SHORT).show()
    }

    override fun onStop() {
        if (viewModel.isTimerRunning) {
            viewModel.saveTrackingTime(SystemClock.elapsedRealtime() - chronometer.base)
        }

        super.onStop()
    }

    // function to set up toolbar with collapse toolbar and link to drawer layout
    private fun setUpToolbar() {
        val mainActivity = activity as MainActivity
        // imperative to see option menu and navigation icon (hamburger)
        mainActivity.setSupportActionBar(binding.toolbar)

        val navController = findNavController()
        // retrieve app bar configuration : see MainActivity.class
        val appBarConfiguration = mainActivity.appBarConfiguration

        // to set hamburger menu work and open drawer layout
        binding.toolbar.setupWithNavController(navController, appBarConfiguration)
        binding.toolbar.setNavigationOnClickListener {
            navController.navigateUp(appBarConfiguration)
        }
    }

    private fun playAlertSound(): Boolean {
        if (soundID != 0)
            soundPool.play(soundID, 0.1F, 0.1F,0, 0,1.1F)
        return true
    }
}