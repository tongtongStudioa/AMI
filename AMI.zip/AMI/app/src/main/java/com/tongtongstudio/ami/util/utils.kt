package com.tongtongstudio.todolistami.util

val <T> T.exhaustive: T
    get() = this